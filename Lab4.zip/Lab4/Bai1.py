a = int(input('Input number: '))
for i in range (0,a,1):
    print(i * '#')                                  