while True:
    a = int(input('Input a positive number: '))
    if a >= 0:
        print('Thank you.')
        break
    else:
        continue