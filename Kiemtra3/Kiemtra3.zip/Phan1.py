# def check_num (num):
#     if num % 2 == 0 :
#         return True
#     else:
#         return False
# number = int(input('Input a number: '))
# if check_num(number):
#     print(f'{int(number)} is even')
# else:
#     print(f'{int(number)} is not even')

#2
# def cal_area(rad):
#     area = rad**2*3.14
#     return area
# radius = int(input('Input radius: '))
# print(f'Circle area: {cal_area(radius)}')

#3
# def reverse_str(text):
#     text = text[::-1]
#     return text
# input = str(input('Input a text: '))
# print(f'Reversed Text: {reverse_str(input)}')\
def is_palindrome(rev_text):
    if rev_text == rev_text[::-1]:
        return True
    else:
        return False
text = input('Input a text: ')
if is_palindrome(text):
    print('This is a palindrome')
else: 
    print('This is not a palindrome')

