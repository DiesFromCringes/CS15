l = ["Bill", "Bob", "John", "Rose", "Mike"]
l.insert(1, l.pop(3))
print(str(l))