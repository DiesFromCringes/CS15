menu = [('Ribeye Steak', 30), ('Potato Salad', 7)]
food = [menu[0]]
print(food)