a = int(input('Input number: '))
result = 0
for i in range (0, (a + 1), 1):
    if a < 0:
        print('Invalid')
    else:
        print(f'{a}! = {a}')
        for => result = result * i