a = ['BĐ', 'BTL', 'CG', 'ĐĐ', 'HBT ']
b = ['247100', '333300', '266800', '420900', '318000']
c = max(b)
e = min(b)
d = b.index(c)
f = b.index(e)
print(d)
print(f'Indice of: \n - Most populated dist.: {d} \n - Least populated dist.: {f}' )