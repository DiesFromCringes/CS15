a = [5, 1, 8, 92, 7, 30]
for num in a:
    if num % 2 == 0 :
        print(num)