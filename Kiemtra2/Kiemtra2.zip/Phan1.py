color = ['blue', 'red', 'green']
print(str(color))
a = input('Input new color: ')
color.append(a)
print(f'New color list: {color}')