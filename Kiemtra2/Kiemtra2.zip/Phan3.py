# # a = [5, 1, 8, 92, -1, 30]
# b = int(input('Input a number: '))
# if b in a:
#     c = a.index(b)
#     print(f'Number found at position {c}')
# else:
#     print('Number not found')
# sum = 0
# for i in range(len(a)):
#     sum = sum + a[i]
# print(f'Sum of all numbers: {sum}')
a = []
b = input('Input: ')
a = a + [b]
print(a)