import math
length = input('Type your length: ')
x = int(length) * (math.sqrt(2))
print('Length of edge: ' + length)
print('Length of diagonal line: ' + str(x))