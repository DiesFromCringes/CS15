value = input('Type your radius: ')
x = 3.14
y = int(value)**2
print(f'Radius: {value}')
print('Perimeter: ' +  str(int(value) * x))
print('Area: ' + str(x*y))
