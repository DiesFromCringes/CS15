name = input('Type your name: ')
domain = input('Type your domain: ')
print(name + domain)