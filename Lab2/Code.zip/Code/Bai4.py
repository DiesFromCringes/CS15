Date = input('Type your date: ')
print(Date)