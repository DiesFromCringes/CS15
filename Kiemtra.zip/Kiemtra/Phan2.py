#1
# for i in range (3, 13):
#     print(i)
#2
# a = int(input('Input a number: '))
# for h in range(0, a+1):
#     if a > 0:
#         print(h)
#3
# a = int(input('Input a number: '))
# for h in range(1, a+1, 2):
#     if a > 0:
#         print(h)
#4
# from turtle import *
# n = 5
# angle = 180 - 180 * (n - 2) / n
# for edge in range(n):
#     right(angle)
#     forward(100)

# mainloop()