#1
# a = int(input('Input a number: '))
# if a > 13 :
#     print('This number is larger than 13')
# else:
#     print('This number is not larger than 13')
#2
# a = int(input('Input a number: '))
# if a % 2 == 0 :
#     print('This number is even')
# else:
#     print('This number is not even')
#3
# a = int(input('Input a month: '))
# if a == 1 or a == 3 or a == 5 or a == 7 or a == 8 or a == 10 or a == 12:
#     print('This month has 31 days')
# elif a == 2:
#     print('This month has 29 days')
# else:
#     print('This month has 30 days')