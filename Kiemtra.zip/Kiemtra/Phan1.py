# #1
# a = input('First name: ')
# b = input('Last name: ')
# #2
#  print('Your full name is '+ (a + ' ' + b))
#  input = input('Your input: ')
#  print(input.upper())
# #3
#  num = int(input('Input a number: '))
#  print('Squared input: ' + str(num**2))
#4
# from turtle import *
# radius = int(input('Input circle radius: '))
# circle(radius=radius)
# mainloop()