print('Name \t:\tThang') 
print('Birthdate \t:\t 25/12/2009')   