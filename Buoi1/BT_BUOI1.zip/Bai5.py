from turtle import *
shape(name='turtle')
forward(100)
left(120)
forward(100)
left(120)
forward(100)