year = input('What year is it \n')
 
print('\tHAPPY NEW YEAR\n\t20' + ' !!! ' + str(year) + ' !!!')