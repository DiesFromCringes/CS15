user_name = input('Input your name: ')
print('Welcome, ' + user_name)